1、针对增加 WT_WRITE_EFUSE_FREE 
2、修复测试pass闪退